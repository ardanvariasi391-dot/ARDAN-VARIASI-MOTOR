package com.ardanvariasimotor.kasir;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.pdf.PrintedPdfDocument;
import android.print.PrintManager;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.FileOutputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    SharedPreferences db;
    LinearLayout content;
    ArrayList<Product> products = new ArrayList<>();
    ArrayList<CartItem> cart = new ArrayList<>();
    NumberFormat rp = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
    int BG = 0xFF151719, CARD = 0xFF242629, INPUT = 0xFF090A0B, WHITE = 0xFFF5F5F5,
        MUTED = 0xFFB9BDC3, YELLOW = 0xFFFFC107, GREEN = 0xFF43D17A, BLUE = 0xFF38BDF8;

    static class Product {
        String id, name, category; int sell, cost, stock;
        Product(String id,String name,String category,int sell,int cost,int stock){this.id=id;this.name=name;this.category=category;this.sell=sell;this.cost=cost;this.stock=stock;}
    }
    static class CartItem { Product p; int qty; CartItem(Product p,int qty){this.p=p;this.qty=qty;} }

    @Override public void onCreate(Bundle b){super.onCreate(b); rp.setMaximumFractionDigits(0); db=getSharedPreferences("ardan_variasi_motor",MODE_PRIVATE); loadProducts(); showHome();}

    TextView text(String s,float size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(WHITE);v.setPadding(18,14,18,14);return v;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(16);b.setTextColor(WHITE);b.setAllCaps(false);b.setMinHeight(58);return b;}
    EditText edit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(MUTED);e.setTextColor(WHITE);e.setTextSize(17);e.setSingleLine(true);e.setPadding(16,10,16,10);e.setBackgroundColor(INPUT);return e;}
    TextView title(String s){TextView t=text(s,28);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(20,22,20,16);return t;}
    void page(String title){LinearLayout all=new LinearLayout(this);all.setOrientation(LinearLayout.VERTICAL);all.setBackgroundColor(BG);all.addView(title(title),new LinearLayout.LayoutParams(-1,-2));ScrollView scroll=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(16,0,16,22);scroll.addView(content);all.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(all);}
    void add(View v){content.addView(v,new LinearLayout.LayoutParams(-1,-2));}
    void addSpace(int h){Space s=new Space(this);add(s);s.getLayoutParams().height=h;}
    TextView cardText(String s,float size){TextView v=text(s,size);v.setBackgroundColor(CARD);v.setPadding(20,18,20,18);return v;}
    Button bigButton(String s){Button b=button(s);b.setTextSize(18);b.setMinHeight(70);return b;}
    void backButton(){Button b=button("← Kembali");b.setOnClickListener(v->showHome());add(b);}

    void showHome(){
        page("ARDAN VARIASI MOTOR");
        TextView sub=text("KASIR OFFLINE  •  JOK / SEAT  •  SKOTLITE",15);sub.setTextColor(MUTED);add(sub);
        addSpace(8);
        add(cardText("Selamat datang 👋\nKelola penjualan, stok, opname admin, dan laporan dari satu aplikasi.",16));
        addSpace(12);
        Button kasir=bigButton("🛒  KASIR");kasir.setOnClickListener(v->showKasir());add(kasir);
        Button stok=bigButton("📦  STOK & PRODUK");stok.setOnClickListener(v->showProducts());add(stok);
        Button laporan=bigButton("📊  LAPORAN HARIAN / BULANAN");laporan.setOnClickListener(v->showReports());add(laporan);
        addSpace(6);
        Button opname=button("🔐  OPNAME STOCK (ADMIN)");opname.setOnClickListener(v->admin(this::showOpname));add(opname);
        Button pin=button("🔑  GANTI PIN ADMIN");pin.setOnClickListener(v->admin(this::changePin));add(pin);
    }

    void showProducts(){
        page("STOK & PRODUK");
        add(cardText("📦 STOK\nPantau stok saat ini. Perubahan stok opname hanya untuk admin.",17));addSpace(10);
        Button addProduct=bigButton("＋  TAMBAH PRODUK BARU");addProduct.setOnClickListener(v->addProduct());add(addProduct);addSpace(8);
        if(products.isEmpty()) add(cardText("Belum ada produk. Tambahkan produk pertama di bawah.",16));
        for(Product p:products){
            TextView v=cardText(""+p.name+"\n"+(p.category.isEmpty()?"Umum":p.category)+"\nHarga jual  : "+money(p.sell)+"\nModal       : "+money(p.cost)+"\nSTOK        : "+p.stock,16);v.setPadding(20,18,20,18);add(v);addSpace(8);
        }
        Button op=button("🔐 Buka OPNAME STOCK (ADMIN)");op.setOnClickListener(v->admin(this::showOpname));add(op);backButton();
    }

    void addProduct(){
        page("TAMBAH PRODUK");add(cardText("Masukkan data barang. Gunakan harga jual dan modal agar laporan laba lebih akurat.",16));addSpace(8);
        EditText name=edit("Nama produk"),cat=edit("Kategori (contoh: Jok / Skotlite)"),sell=edit("Harga jual"),cost=edit("Harga modal"),stock=edit("Stok awal");
        sell.setInputType(InputType.TYPE_CLASS_NUMBER);cost.setInputType(InputType.TYPE_CLASS_NUMBER);stock.setInputType(InputType.TYPE_CLASS_NUMBER);
        add(name);addSpace(8);add(cat);addSpace(8);add(sell);addSpace(8);add(cost);addSpace(8);add(stock);addSpace(10);
        Button save=bigButton("💾  SIMPAN PRODUK");save.setOnClickListener(v->{if(name.getText().toString().trim().isEmpty()){toast("Nama produk wajib diisi");return;}products.add(new Product(UUID.randomUUID().toString(),name.getText().toString().trim(),cat.getText().toString().trim(),num(sell),num(cost),num(stock)));saveProducts();toast("Produk tersimpan");showProducts();});add(save);
        Button cancel=button("BATAL");cancel.setOnClickListener(v->showProducts());add(cancel);
    }

    void showKasir(){
        page("KASIR");
        add(cardText("Pilih jumlah barang dengan tombol − dan +. Barang akan masuk ke keranjang secara otomatis.",16));addSpace(8);
        int totalCart=0;for(CartItem c:cart)totalCart+=c.p.sell*c.qty;
        TextView cartInfo=cardText("🛒 KERANJANG\n"+(cart.isEmpty()?"Belum ada barang":"Ada "+cart.size()+" jenis barang")+"\nTotal sementara: "+money(totalCart),17);add(cartInfo);addSpace(10);
        if(products.isEmpty()) add(cardText("Belum ada produk. Masuk ke STOK & PRODUK untuk menambah barang.",16));
        for(Product p:products){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(14,10,8,10);row.setBackgroundColor(CARD);
            TextView info=text(p.name+"\n"+money(p.sell)+"  •  stok "+p.stock,17);info.setTypeface(Typeface.DEFAULT,Typeface.BOLD);row.addView(info,new LinearLayout.LayoutParams(0,80,1));
            Button minus=button("−"),qty=button("0"),plus=button("+");minus.setMinWidth(52);qty.setMinWidth(58);plus.setMinWidth(52);final int[] q={cartQty(p)};qty.setText(String.valueOf(q[0]));
            minus.setOnClickListener(v->{if(q[0]>0)q[0]--;qty.setText(String.valueOf(q[0]));updateCart(p,q[0]);});
            plus.setOnClickListener(v->{if(q[0]>=p.stock){toast("Stok tidak cukup");return;}q[0]++;qty.setText(String.valueOf(q[0]));updateCart(p,q[0]);});
            row.addView(minus);row.addView(qty);row.addView(plus);content.addView(row);addSpace(7);
        }
        Button pay=bigButton("💳  BAYAR / CHECKOUT");pay.setOnClickListener(v->checkout());add(pay);backButton();
    }
    int cartQty(Product p){for(CartItem c:cart)if(c.p.id.equals(p.id))return c.qty;return 0;}
    void updateCart(Product p,int q){CartItem found=null;for(CartItem c:cart)if(c.p.id.equals(p.id)){found=c;break;}if(q<=0){if(found!=null)cart.remove(found);}else if(found==null)cart.add(new CartItem(p,q));else found.qty=q;}

    void checkout(){
        if(cart.isEmpty()){toast("Keranjang kosong");return;}int sub=0,profit=0;for(CartItem c:cart){sub+=c.p.sell*c.qty;profit+=(c.p.sell-c.p.cost)*c.qty;}final int subtotal=sub,profitFinal=profit;
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(8,0,8,0);EditText disc=edit("Diskon Rp"),pay=edit("Bayar / DP Rp");disc.setInputType(InputType.TYPE_CLASS_NUMBER);pay.setInputType(InputType.TYPE_CLASS_NUMBER);box.addView(disc);addViewSpace(box,8);box.addView(pay);
        new AlertDialog.Builder(this).setTitle("💳 PEMBAYARAN").setMessage("Subtotal: "+money(subtotal)).setView(box).setPositiveButton("SIMPAN",(dialog,which)->{
            int total=Math.max(0,subtotal-num(disc));int paid=num(pay);if(paid<total){toast("Pembayaran kurang");return;}for(CartItem c:cart)c.p.stock-=c.qty;saveProducts();int change=paid-total;
            StringBuilder r=new StringBuilder();r.append("ARDAN VARIASI MOTOR\n");r.append("==============================\n");r.append(new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US).format(new Date())).append("\n");r.append("------------------------------\n");for(CartItem c:cart)r.append(c.p.name).append("\n  ").append(c.qty).append(" x ").append(money(c.p.sell)).append(" = ").append(money(c.p.sell*c.qty)).append("\n");r.append("------------------------------\n");r.append("Subtotal : ").append(money(subtotal)).append("\nDiskon   : ").append(money(num(disc))).append("\nTOTAL    : ").append(money(total)).append("\nBayar    : ").append(money(paid)).append("\nKembali  : ").append(money(change)).append("\n==============================\nTerima kasih.");
            String receipt=r.toString();String old=db.getString("sales","");String date=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());db.edit().putString("sales",old+date+"|"+total+"|"+profitFinal+"\n").apply();cart.clear();showReceiptDialog(receipt);}).setNegativeButton("BATAL",null).show();
    }

    void addViewSpace(LinearLayout box,int h){Space s=new Space(this);box.addView(s,new LinearLayout.LayoutParams(1,h));}
    void showReceiptDialog(final String receipt){
        TextView tv=cardText(receipt,16);tv.setTextIsSelectable(true);ScrollView sc=new ScrollView(this);sc.addView(tv);LinearLayout box=new LinearLayout(this);box.setPadding(12,0,12,0);box.addView(sc,new LinearLayout.LayoutParams(-1,520));
        new AlertDialog.Builder(this).setTitle("✅ TRANSAKSI BERHASIL").setView(box).setPositiveButton("🖨️ CETAK STRUK",(d,w)->printReceipt(receipt)).setNeutralButton("📤 WHATSAPP",(d,w)->share(receipt)).setNegativeButton("SELESAI",(d,w)->showHome()).show();
    }

    void printReceipt(final String receipt){
        PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);if(pm==null){toast("Fitur cetak tidak tersedia di perangkat ini");return;}pm.print("Struk ARDAN VARIASI MOTOR",new ReceiptPrintAdapter(receipt),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
    }
    class ReceiptPrintAdapter extends PrintDocumentAdapter{
        String receipt;ReceiptPrintAdapter(String r){receipt=r;}
        public void onLayout(PrintAttributes oldA,PrintAttributes newA,CancellationSignal cs,LayoutResultCallback cb,Bundle extras){if(cs.isCanceled()){cb.onLayoutCancelled();return;}PrintDocumentInfo info=new PrintDocumentInfo.Builder("Struk-ARDAN-VARIASI-MOTOR.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build();cb.onLayoutFinished(info,true);}
        public void onWrite(PageRange[] pages,ParcelFileDescriptor fd,CancellationSignal cs,WriteResultCallback cb){PrintedPdfDocument doc=new PrintedPdfDocument(MainActivity.this,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());android.graphics.pdf.PdfDocument.Page page=doc.startPage(1);Canvas c=page.getCanvas();Paint p=new Paint();p.setColor(0xFF000000);p.setTextSize(12);p.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.NORMAL));float x=36,y=45;for(String line:receipt.split("\\n")){if(y>800)break;c.drawText(line,x,y,p);y+=18;}doc.finishPage(page);try{FileOutputStream out=new FileOutputStream(fd.getFileDescriptor());doc.writeTo(out);out.flush();out.close();doc.close();fd.close();cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){doc.close();try{fd.close();}catch(Exception ignored){}cb.onWriteFailed(e.getMessage());}}
    }

    void showOpname(){page("OPNAME STOCK");add(cardText("🔐 MODE ADMIN\nHanya admin yang dapat mengubah jumlah stok.",17));addSpace(10);for(Product p:products){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setBackgroundColor(CARD);row.setPadding(8,8,8,8);TextView n=text(p.name+"\nStok saat ini: "+p.stock,16);row.addView(n,new LinearLayout.LayoutParams(0,80,1));EditText st=edit("Stok");st.setInputType(InputType.TYPE_CLASS_NUMBER);st.setText(String.valueOf(p.stock));row.addView(st,new LinearLayout.LayoutParams(120,70));Button save=button("Simpan");save.setOnClickListener(v->{p.stock=num(st);saveProducts();toast("Stok diperbarui");});row.addView(save);content.addView(row);addSpace(8);}backButton();}

    void showReports(){page("LAPORAN");String raw=db.getString("sales","");String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());String month=today.substring(0,7);int daySales=0,dayProfit=0,monthSales=0,monthProfit=0,count=0;for(String line:raw.split("\\n")){if(line.trim().isEmpty())continue;String[] a=line.split("\\|");if(a.length<3)continue;try{int total=Integer.parseInt(a[1]),profit=Integer.parseInt(a[2]);count++;if(a[0].startsWith(today)){daySales+=total;dayProfit+=profit;}if(a[0].startsWith(month)){monthSales+=total;monthProfit+=profit;}}catch(Exception ignored){}}add(cardText("📅 HARI INI\nPenjualan : "+money(daySales)+"\nLaba       : "+money(dayProfit)+"\n\n📆 BULAN INI\nPenjualan : "+money(monthSales)+"\nLaba       : "+money(monthProfit)+"\nTransaksi  : "+count,18));addSpace(10);final int fds=daySales,fdp=dayProfit,fms=monthSales,fmp=monthProfit;final String fm=month;Button share=bigButton("📤  BAGIKAN LAPORAN");share.setOnClickListener(v->share("ARDAN VARIASI MOTOR\nLaporan "+fm+"\nPenjualan bulan: "+money(fms)+"\nLaba bulan: "+money(fmp)+"\nPenjualan hari ini: "+money(fds)+"\nLaba hari ini: "+money(fdp)));add(share);backButton();}

    void admin(final Runnable action){EditText pin=edit("PIN Admin");pin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);new AlertDialog.Builder(this).setTitle("🔐 AKSES ADMIN").setView(pin).setPositiveButton("MASUK",(d,w)->{if(db.getString("pin","1234").equals(pin.getText().toString()))action.run();else toast("PIN salah");}).setNegativeButton("BATAL",null).show();}
    void changePin(){EditText old=edit("PIN lama"),newer=edit("PIN baru");old.setInputType(18);newer.setInputType(18);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.addView(old);addViewSpace(box,8);box.addView(newer);new AlertDialog.Builder(this).setTitle("Ganti PIN Admin").setView(box).setPositiveButton("SIMPAN",(d,w)->{if(!db.getString("pin","1234").equals(old.getText().toString())){toast("PIN lama salah");return;}String n=newer.getText().toString();if(n.length()<4){toast("PIN minimal 4 angka");return;}db.edit().putString("pin",n).apply();toast("PIN berhasil diganti");}).setNegativeButton("BATAL",null).show();}

    int num(EditText e){try{String s=e.getText().toString().replace(".","").replace(",","").trim();return s.isEmpty()?0:Integer.parseInt(s);}catch(Exception ex){return 0;}}
    String money(int n){return rp.format(n).replace("Rp","Rp ");}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    void share(String s){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,s);startActivity(Intent.createChooser(i,"Bagikan / WhatsApp"));}
    void loadProducts(){products.clear();String raw=db.getString("products","");if(raw.isEmpty())return;for(String line:raw.split("\\n")){String[] a=line.split("\\|",-1);if(a.length<6)continue;try{products.add(new Product(a[0],a[1],a[2],Integer.parseInt(a[3]),Integer.parseInt(a[4]),Integer.parseInt(a[5])));}catch(Exception ignored){}}}
    void saveProducts(){StringBuilder s=new StringBuilder();for(Product p:products)s.append(p.id).append('|').append(p.name.replace("|"," ")).append('|').append(p.category.replace("|"," ")).append('|').append(p.sell).append('|').append(p.cost).append('|').append(p.stock).append('\n');db.edit().putString("products",s.toString()).apply();}
}
