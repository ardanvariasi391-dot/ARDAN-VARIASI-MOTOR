package com.ardanvariasimotor.kasir;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.print.pdf.PrintedPdfDocument;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.FileOutputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    SharedPreferences db;
    LinearLayout content;
    ArrayList<Product> products = new ArrayList<>();
    ArrayList<CartItem> cart = new ArrayList<>();
    NumberFormat rp = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));

    // New visual system — existing menu/function logic is retained.
    final int BG = Color.rgb(246,247,249), CARD = Color.WHITE, DARK = Color.rgb(27,31,36),
            RED = Color.rgb(224,25,30), RED_DARK = Color.rgb(178,14,18), MUTED = Color.rgb(103,111,120),
            BORDER = Color.rgb(226,229,233), GREEN = Color.rgb(35,170,91), BLUE = Color.rgb(38,119,224),
            PURPLE = Color.rgb(113,67,202), ORANGE = Color.rgb(239,137,24);

    static class Product {
        String id, name, category; int sell, cost, stock;
        Product(String id,String name,String category,int sell,int cost,int stock){this.id=id;this.name=name;this.category=category;this.sell=sell;this.cost=cost;this.stock=stock;}
    }
    static class CartItem { Product p; int qty; CartItem(Product p,int qty){this.p=p;this.qty=qty;} }

    @Override public void onCreate(Bundle b){super.onCreate(b); rp.setMaximumFractionDigits(0); db=getSharedPreferences("ardan_variasi_motor",MODE_PRIVATE); loadProducts(); showHome();}

    GradientDrawable bg(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);return g;}
    GradientDrawable outline(int fill,int stroke,float radius){GradientDrawable g=bg(fill,radius);g.setStroke(dp(1),stroke);return g;}
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    LinearLayout.LayoutParams lp(int w,int h,int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(0,dp(top),0,dp(bottom));return p;}
    void margin(View v,int l,int t,int r,int b){if(v.getLayoutParams() instanceof ViewGroup.MarginLayoutParams){ViewGroup.MarginLayoutParams p=(ViewGroup.MarginLayoutParams)v.getLayoutParams();p.setMargins(dp(l),dp(t),dp(r),dp(b));v.setLayoutParams(p);}}

    TextView text(String s,float size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(DARK);v.setGravity(Gravity.CENTER_VERTICAL);v.setFontFeatureSettings("kern");return v;}
    TextView whiteText(String s,float size){TextView v=text(s,size);v.setTextColor(Color.WHITE);return v;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(15);b.setTextColor(DARK);b.setAllCaps(false);b.setMinHeight(dp(52));b.setPadding(dp(12),0,dp(12),0);b.setStateListAnimator(null);b.setBackground(outline(Color.WHITE,BORDER,16));return b;}
    Button primary(String s){Button b=button(s);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(16);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setMinHeight(dp(56));b.setBackground(bg(RED,16));return b;}
    EditText edit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(MUTED);e.setTextColor(DARK);e.setTextSize(16);e.setSingleLine(true);e.setPadding(dp(14),0,dp(14),0);e.setBackground(outline(Color.WHITE,BORDER,14));return e;}
    TextView title(String s){TextView t=whiteText(s,21);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(dp(18),0,dp(18),0);return t;}

    void page(String title){
        LinearLayout all=new LinearLayout(this);all.setOrientation(LinearLayout.VERTICAL);all.setBackgroundColor(BG);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(4),dp(8),dp(12),dp(8));bar.setBackground(bg(RED,0));
        Button back=new Button(this);back.setText("‹");back.setTextColor(Color.WHITE);back.setTextSize(32);back.setGravity(Gravity.CENTER);back.setPadding(0,0,0,dp(3));back.setBackgroundColor(Color.TRANSPARENT);back.setOnClickListener(v->showHome());bar.addView(back,new LinearLayout.LayoutParams(dp(48),dp(52)));
        bar.addView(title(title),new LinearLayout.LayoutParams(0,dp(52),1));
        TextView brand=whiteText("ARDAN",12);brand.setTypeface(Typeface.DEFAULT,Typeface.BOLD);brand.setGravity(Gravity.CENTER);bar.addView(brand,new LinearLayout.LayoutParams(dp(62),dp(52)));
        all.addView(bar,new LinearLayout.LayoutParams(-1,dp(68)));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(16),dp(16),dp(16),dp(28));scroll.addView(content);all.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(all);
    }
    void add(View v){content.addView(v,new LinearLayout.LayoutParams(-1,-2));}
    void add(View v,int top,int bottom){content.addView(v,lp(-1,-2,top,bottom));}
    void addSpace(int h){Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,dp(h)));}
    TextView cardText(String s,float size){TextView v=text(s,size);v.setBackground(outline(CARD,BORDER,16));v.setPadding(dp(18),dp(16),dp(18),dp(16));return v;}
    Button bigButton(String s){Button b=primary(s);b.setMinHeight(dp(64));return b;}

    TextView section(String s){TextView v=text(s,14);v.setTextColor(MUTED);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setPadding(dp(2),dp(4),dp(2),dp(6));return v;}
    TextView badge(String s,int color){TextView v=whiteText(s,12);v.setGravity(Gravity.CENTER);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setPadding(dp(9),0,dp(9),0);v.setBackground(bg(color,30));return v;}
    LinearLayout tile(String icon,String name,String sub,int color){
        LinearLayout t=new LinearLayout(this);t.setOrientation(LinearLayout.VERTICAL);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(14),dp(13),dp(14),dp(13));t.setBackground(outline(CARD,BORDER,18));
        TextView i=whiteText(icon,25);i.setGravity(Gravity.CENTER);i.setBackground(bg(color,14));t.addView(i,new LinearLayout.LayoutParams(dp(50),dp(50)));
        TextView n=text(name,16);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.addView(n,lp(-1,-2,10,1));
        TextView ss=text(sub,12);ss.setTextColor(MUTED);t.addView(ss);
        return t;
    }

    void showHome(){
        LinearLayout all=new LinearLayout(this);all.setOrientation(LinearLayout.VERTICAL);all.setBackgroundColor(BG);
        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.HORIZONTAL);hero.setGravity(Gravity.CENTER_VERTICAL);hero.setPadding(dp(18),dp(16),dp(18),dp(16));hero.setBackground(bg(DARK,0));
        LinearLayout texts=new LinearLayout(this);texts.setOrientation(LinearLayout.VERTICAL);TextView a=whiteText("ARDAN",26);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);TextView vm=whiteText("VARIASI MOTOR",14);vm.setTypeface(Typeface.DEFAULT,Typeface.BOLD);texts.addView(a);texts.addView(vm);TextView sub=whiteText("KASIR OFFLINE",11);sub.setTextColor(Color.LTGRAY);texts.addView(sub);hero.addView(texts,new LinearLayout.LayoutParams(0,dp(82),1));TextView gear=whiteText("⚙",27);gear.setGravity(Gravity.CENTER);hero.addView(gear,new LinearLayout.LayoutParams(dp(55),dp(55)));all.addView(hero,new LinearLayout.LayoutParams(-1,dp(114)));
        ScrollView scroll=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(16),dp(16),dp(16),dp(28));scroll.addView(content);all.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(all);

        LinearLayout welcome=new LinearLayout(this);welcome.setOrientation(LinearLayout.VERTICAL);welcome.setPadding(dp(18),dp(15),dp(18),dp(15));welcome.setBackground(outline(CARD,BORDER,18));
        TextView w=text("Selamat datang 👋",18);w.setTypeface(Typeface.DEFAULT,Typeface.BOLD);welcome.addView(w);TextView ws=text("Kelola penjualan, stok, opname, dan laporan dengan cepat.",13);ws.setTextColor(MUTED);welcome.addView(ws);add(welcome,0,14);
        add(section("MENU UTAMA"));
        LinearLayout r1=new LinearLayout(this);r1.setOrientation(LinearLayout.HORIZONTAL);r1.setWeightSum(2);LinearLayout kas=(LinearLayout)tile("🛒","Kasir","Transaksi penjualan",RED);kas.setOnClickListener(v->showKasir());LinearLayout stok=(LinearLayout)tile("📦","Stok & Produk","Kelola barang",DARK);stok.setOnClickListener(v->showProducts());r1.addView(kas,lp(0,dp(156),0,0));r1.getChildAt(0).getLayoutParams().width=0;((LinearLayout.LayoutParams)r1.getChildAt(0).getLayoutParams()).weight=1;r1.addView(stok,lp(0,dp(156),0,0));((LinearLayout.LayoutParams)r1.getChildAt(1).getLayoutParams()).weight=1;content.addView(r1);addSpace(10);
        LinearLayout r2=new LinearLayout(this);r2.setOrientation(LinearLayout.HORIZONTAL);LinearLayout lap=(LinearLayout)tile("📊","Laporan","Penjualan & laba",BLUE);lap.setOnClickListener(v->showReports());LinearLayout op=(LinearLayout)tile("✓","Opname Stock","Akses admin",GREEN);op.setOnClickListener(v->admin(this::showOpname));r2.addView(lap,lp(0,dp(156),0,0));((LinearLayout.LayoutParams)r2.getChildAt(0).getLayoutParams()).weight=1;r2.addView(op,lp(0,dp(156),0,0));((LinearLayout.LayoutParams)r2.getChildAt(1).getLayoutParams()).weight=1;content.addView(r2);addSpace(10);
        LinearLayout r3=new LinearLayout(this);r3.setOrientation(LinearLayout.HORIZONTAL);LinearLayout pin=(LinearLayout)tile("🔑","Ganti PIN","Keamanan admin",PURPLE);pin.setOnClickListener(v->admin(this::changePin));LinearLayout keluar=(LinearLayout)tile("↪","Keluar","Tutup aplikasi",ORANGE);keluar.setOnClickListener(v->finish());r3.addView(pin,lp(0,dp(140),0,0));((LinearLayout.LayoutParams)r3.getChildAt(0).getLayoutParams()).weight=1;r3.addView(keluar,lp(0,dp(140),0,0));((LinearLayout.LayoutParams)r3.getChildAt(1).getLayoutParams()).weight=1;content.addView(r3);
        addSpace(14);TextView foot=text("ARDAN VARIASI MOTOR  •  Versi 1.1",12);foot.setTextColor(MUTED);foot.setGravity(Gravity.CENTER);add(foot);
    }

    void showProducts(){
        page("Stok & Produk");add(cardText("📦  Kelola semua barang dan pantau stok yang tersedia. Perubahan stok melalui Opname hanya untuk admin.",15),0,12);
        Button addProduct=bigButton("＋  TAMBAH PRODUK BARU");addProduct.setOnClickListener(v->addProduct());add(addProduct,0,16);
        add(section("DAFTAR PRODUK  •  "+products.size()+" ITEM"));
        if(products.isEmpty()) add(cardText("Belum ada produk. Tambahkan produk pertama melalui tombol di atas.",15),0,10);
        for(Product p:products){
            LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(14),dp(12),dp(10),dp(12));row.setBackground(outline(CARD,BORDER,16));
            TextView icon=whiteText("▣",22);icon.setGravity(Gravity.CENTER);icon.setBackground(bg(DARK,14));row.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
            LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(12),0,dp(4),0);TextView n=text(p.name,16);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(n);TextView c=text((p.category.isEmpty()?"Umum":p.category)+"  •  "+money(p.sell),13);c.setTextColor(MUTED);info.addView(c);TextView st=text("Stok: "+p.stock,13);st.setTextColor(p.stock<=3?RED:GREEN);st.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(st);row.addView(info,new LinearLayout.LayoutParams(0,dp(72),1));content.addView(row,lp(-1,-2,0,8));
        }
        Button op=button("🔐  BUKA OPNAME STOCK (ADMIN)");op.setOnClickListener(v->admin(this::showOpname));add(op,4,0);
    }

    void addProduct(){
        page("Tambah Produk");add(cardText("Masukkan data barang. Harga modal digunakan untuk menghitung laba pada laporan.",15),0,12);
        EditText name=edit("Nama produk"),cat=edit("Kategori (contoh: Aksesoris)"),sell=edit("Harga jual"),cost=edit("Harga modal"),stock=edit("Stok awal");sell.setInputType(InputType.TYPE_CLASS_NUMBER);cost.setInputType(InputType.TYPE_CLASS_NUMBER);stock.setInputType(InputType.TYPE_CLASS_NUMBER);
        add(name,0,8);add(cat,0,8);add(sell,0,8);add(cost,0,8);add(stock,0,14);
        Button save=primary("💾  SIMPAN PRODUK");save.setOnClickListener(v->{if(name.getText().toString().trim().isEmpty()){toast("Nama produk wajib diisi");return;}products.add(new Product(UUID.randomUUID().toString(),name.getText().toString().trim(),cat.getText().toString().trim(),num(sell),num(cost),num(stock)));saveProducts();toast("Produk tersimpan");showProducts();});add(save,0,8);
        Button cancel=button("BATAL");cancel.setOnClickListener(v->showProducts());add(cancel);
    }

    void showKasir(){
        page("Kasir");
        int totalCart=0,totalQty=0;for(CartItem c:cart){totalCart+=c.p.sell*c.qty;totalQty+=c.qty;}
        LinearLayout sum=new LinearLayout(this);sum.setPadding(dp(16),dp(12),dp(16),dp(12));sum.setGravity(Gravity.CENTER_VERTICAL);sum.setBackground(outline(CARD,BORDER,18));TextView s1=text("KERANJANG\n"+totalQty+" item",14);s1.setTypeface(Typeface.DEFAULT,Typeface.BOLD);TextView s2=text(money(totalCart),19);s2.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);s2.setTypeface(Typeface.DEFAULT,Typeface.BOLD);s2.setTextColor(RED);sum.addView(s1,new LinearLayout.LayoutParams(0,dp(56),1));sum.addView(s2,new LinearLayout.LayoutParams(dp(150),dp(56)));add(sum,0,14);
        add(section("PILIH PRODUK"));
        if(products.isEmpty()) add(cardText("Belum ada produk. Masuk ke Stok & Produk untuk menambahkan barang.",15),0,10);
        for(Product p:products){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(8),dp(8),dp(8));row.setBackground(outline(CARD,BORDER,16));
            TextView icon=whiteText("●",14);icon.setGravity(Gravity.CENTER);icon.setBackground(bg(RED,20));row.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(42)));
            TextView info=text(p.name+"\n"+money(p.sell)+"  •  stok "+p.stock,14);info.setTypeface(Typeface.DEFAULT,Typeface.BOLD);row.addView(info,new LinearLayout.LayoutParams(0,dp(66),1));
            Button minus=button("−"),qty=button("0"),plus=button("+");minus.setMinWidth(dp(44));qty.setMinWidth(dp(52));plus.setMinWidth(dp(44));final int[] q={cartQty(p)};qty.setText(String.valueOf(q[0]));minus.setOnClickListener(v->{if(q[0]>0)q[0]--;qty.setText(String.valueOf(q[0]));updateCart(p,q[0]);});plus.setOnClickListener(v->{if(q[0]>=p.stock){toast("Stok tidak cukup");return;}q[0]++;qty.setText(String.valueOf(q[0]));updateCart(p,q[0]);});row.addView(minus);row.addView(qty);row.addView(plus);content.addView(row,lp(-1,-2,0,8));
        }
        Button pay=bigButton("💳  BAYAR / CHECKOUT");pay.setOnClickListener(v->checkout());add(pay,8,0);
    }
    int cartQty(Product p){for(CartItem c:cart)if(c.p.id.equals(p.id))return c.qty;return 0;}
    void updateCart(Product p,int q){CartItem found=null;for(CartItem c:cart)if(c.p.id.equals(p.id)){found=c;break;}if(q<=0){if(found!=null)cart.remove(found);}else if(found==null)cart.add(new CartItem(p,q));else found.qty=q;}

    void checkout(){
        if(cart.isEmpty()){toast("Keranjang kosong");return;}int sub=0,profit=0;for(CartItem c:cart){sub+=c.p.sell*c.qty;profit+=(c.p.sell-c.p.cost)*c.qty;}final int subtotal=sub,profitFinal=profit;
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(8),0,dp(8),0);EditText disc=edit("Diskon Rp"),pay=edit("Bayar / DP Rp");disc.setInputType(InputType.TYPE_CLASS_NUMBER);pay.setInputType(InputType.TYPE_CLASS_NUMBER);box.addView(disc);addViewSpace(box,8);box.addView(pay);
        new AlertDialog.Builder(this).setTitle("💳 Pembayaran").setMessage("Subtotal: "+money(subtotal)).setView(box).setPositiveButton("SIMPAN",(dialog,which)->{int total=Math.max(0,subtotal-num(disc));int paid=num(pay);if(paid<total){toast("Pembayaran kurang");return;}for(CartItem c:cart)c.p.stock-=c.qty;saveProducts();int change=paid-total;
            StringBuilder r=new StringBuilder();r.append("ARDAN VARIASI MOTOR\n");r.append("==============================\n");r.append(new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US).format(new Date())).append("\n");r.append("------------------------------\n");for(CartItem c:cart)r.append(c.p.name).append("\n  ").append(c.qty).append(" x ").append(money(c.p.sell)).append(" = ").append(money(c.p.sell*c.qty)).append("\n");r.append("------------------------------\n");r.append("Subtotal : ").append(money(subtotal)).append("\nDiskon   : ").append(money(num(disc))).append("\nTOTAL    : ").append(money(total)).append("\nBayar    : ").append(money(paid)).append("\nKembali  : ").append(money(change)).append("\n==============================\nTerima kasih.");
            String receipt=r.toString();String old=db.getString("sales","");String date=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());db.edit().putString("sales",old+date+"|"+total+"|"+profitFinal+"\n").apply();cart.clear();showReceiptDialog(receipt);}).setNegativeButton("BATAL",null).show();
    }
    void addViewSpace(LinearLayout box,int h){Space s=new Space(this);box.addView(s,new LinearLayout.LayoutParams(1,dp(h)));}
    void showReceiptDialog(final String receipt){TextView tv=cardText(receipt,14);tv.setTextIsSelectable(true);ScrollView sc=new ScrollView(this);sc.addView(tv);LinearLayout box=new LinearLayout(this);box.setPadding(dp(12),0,dp(12),0);box.addView(sc,new LinearLayout.LayoutParams(-1,dp(520)));new AlertDialog.Builder(this).setTitle("✅ Transaksi Berhasil").setView(box).setPositiveButton("🖨️ CETAK STRUK",(d,w)->printReceipt(receipt)).setNeutralButton("📤 BAGIKAN STRUK",(d,w)->share(receipt)).setNegativeButton("SELESAI",(d,w)->showHome()).show();}
    void printReceipt(final String receipt){PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);if(pm==null){toast("Fitur cetak tidak tersedia di perangkat ini");return;}pm.print("Struk ARDAN VARIASI MOTOR",new ReceiptPrintAdapter(receipt),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());}
    class ReceiptPrintAdapter extends PrintDocumentAdapter{String receipt;ReceiptPrintAdapter(String r){receipt=r;}public void onLayout(PrintAttributes oldA,PrintAttributes newA,CancellationSignal cs,LayoutResultCallback cb,Bundle extras){if(cs.isCanceled()){cb.onLayoutCancelled();return;}PrintDocumentInfo info=new PrintDocumentInfo.Builder("Struk-ARDAN-VARIASI-MOTOR.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build();cb.onLayoutFinished(info,true);}public void onWrite(PageRange[] pages,ParcelFileDescriptor fd,CancellationSignal cs,WriteResultCallback cb){PrintedPdfDocument doc=new PrintedPdfDocument(MainActivity.this,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());android.graphics.pdf.PdfDocument.Page page=doc.startPage(1);Canvas c=page.getCanvas();Paint p=new Paint();p.setColor(Color.BLACK);p.setTextSize(12);p.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.NORMAL));float x=36,y=45;for(String line:receipt.split("\\n")){if(y>800)break;c.drawText(line,x,y,p);y+=18;}doc.finishPage(page);try{FileOutputStream out=new FileOutputStream(fd.getFileDescriptor());doc.writeTo(out);out.flush();out.close();doc.close();fd.close();cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){doc.close();try{fd.close();}catch(Exception ignored){}cb.onWriteFailed(e.getMessage());}}}

    void showOpname(){page("Opname Stock");add(cardText("🔐  MODE ADMIN\nHanya admin yang dapat mengubah jumlah stok.",15),0,14);for(Product p:products){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),dp(8),dp(8),dp(8));row.setBackground(outline(CARD,BORDER,16));TextView n=text(p.name+"\nStok saat ini: "+p.stock,14);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);row.addView(n,new LinearLayout.LayoutParams(0,dp(72),1));EditText st=edit("Stok");st.setInputType(InputType.TYPE_CLASS_NUMBER);st.setText(String.valueOf(p.stock));row.addView(st,new LinearLayout.LayoutParams(dp(92),dp(54)));Button save=button("Simpan");save.setOnClickListener(v->{p.stock=num(st);saveProducts();toast("Stok diperbarui");});row.addView(save,new LinearLayout.LayoutParams(dp(86),dp(54)));content.addView(row,lp(-1,-2,0,8));}}

    void showReports(){page("Laporan");String raw=db.getString("sales","");String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());String month=today.substring(0,7);int daySales=0,dayProfit=0,monthSales=0,monthProfit=0,count=0;for(String line:raw.split("\\n")){if(line.trim().isEmpty())continue;String[] a=line.split("\\|");if(a.length<3)continue;try{int total=Integer.parseInt(a[1]),profit=Integer.parseInt(a[2]);count++;if(a[0].startsWith(today)){daySales+=total;dayProfit+=profit;}if(a[0].startsWith(month)){monthSales+=total;monthProfit+=profit;}}catch(Exception ignored){}}
        LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);grid.addView(reportCard("TOTAL PENJUALAN\n"+money(monthSales),GREEN),lp(-1,dp(110),0,8));LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);TextView c1=reportCard("TRANSAKSI\n"+count,BLUE);TextView c2=reportCard("LABA BULAN\n"+money(monthProfit),PURPLE);r.addView(c1,lp(0,dp(110),0,0));((LinearLayout.LayoutParams)c1.getLayoutParams()).weight=1;r.addView(c2,lp(0,dp(110),8,0));((LinearLayout.LayoutParams)c2.getLayoutParams()).weight=1;grid.addView(r);content.addView(grid,lp(-1,-2,0,14));
        add(cardText("📅 HARI INI\nPenjualan : "+money(daySales)+"\nLaba       : "+money(dayProfit)+"\n\n📆 BULAN INI\nPenjualan : "+money(monthSales)+"\nLaba       : "+money(monthProfit)+"\nTransaksi  : "+count,15),0,12);final int fds=daySales,fdp=dayProfit,fms=monthSales,fmp=monthProfit;final String fm=month;Button share=primary("📤  BAGIKAN LAPORAN");share.setOnClickListener(v->share("ARDAN VARIASI MOTOR\nLaporan "+fm+"\nPenjualan bulan: "+money(fms)+"\nLaba bulan: "+money(fmp)+"\nPenjualan hari ini: "+money(fds)+"\nLaba hari ini: "+money(fdp)));add(share);}
    TextView reportCard(String s,int color){TextView v=whiteText(s,15);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setGravity(Gravity.CENTER_VERTICAL);v.setPadding(dp(16),0,dp(16),0);v.setBackground(outline(CARD,color,16));return v;}

    void admin(final Runnable action){EditText pin=edit("PIN Admin");pin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);new AlertDialog.Builder(this).setTitle("🔐 Akses Admin").setView(pin).setPositiveButton("MASUK",(d,w)->{if(db.getString("pin","1234").equals(pin.getText().toString()))action.run();else toast("PIN salah");}).setNegativeButton("BATAL",null).show();}
    void changePin(){EditText old=edit("PIN lama"),newer=edit("PIN baru");old.setInputType(18);newer.setInputType(18);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(8),0,dp(8),0);box.addView(old);addViewSpace(box,8);box.addView(newer);new AlertDialog.Builder(this).setTitle("Ganti PIN Admin").setView(box).setPositiveButton("SIMPAN",(d,w)->{if(!db.getString("pin","1234").equals(old.getText().toString())){toast("PIN lama salah");return;}String n=newer.getText().toString();if(n.length()<4){toast("PIN minimal 4 angka");return;}db.edit().putString("pin",n).apply();toast("PIN berhasil diganti");}).setNegativeButton("BATAL",null).show();}
    int num(EditText e){try{String s=e.getText().toString().replace(".","").replace(",","").trim();return s.isEmpty()?0:Integer.parseInt(s);}catch(Exception ex){return 0;}}
    String money(int n){return rp.format(n).replace("Rp","Rp ");}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    void share(String s){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,s);startActivity(Intent.createChooser(i,"Bagikan / WhatsApp"));}
    void loadProducts(){products.clear();String raw=db.getString("products","");if(raw.isEmpty())return;for(String line:raw.split("\\n")){String[] a=line.split("\\|",-1);if(a.length<6)continue;try{products.add(new Product(a[0],a[1],a[2],Integer.parseInt(a[3]),Integer.parseInt(a[4]),Integer.parseInt(a[5])));}catch(Exception ignored){}}}
    void saveProducts(){StringBuilder s=new StringBuilder();for(Product p:products)s.append(p.id).append('|').append(p.name.replace("|"," ")).append('|').append(p.category.replace("|"," ")).append('|').append(p.sell).append('|').append(p.cost).append('|').append(p.stock).append('\n');db.edit().putString("products",s.toString()).apply();}
}
