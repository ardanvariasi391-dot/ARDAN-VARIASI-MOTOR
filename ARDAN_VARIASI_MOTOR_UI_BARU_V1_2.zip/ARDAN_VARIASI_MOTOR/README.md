# ARDAN VARIASI MOTOR
Kasir offline Android. PIN awal: 1234. Build APK otomatis lewat GitHub Actions.
