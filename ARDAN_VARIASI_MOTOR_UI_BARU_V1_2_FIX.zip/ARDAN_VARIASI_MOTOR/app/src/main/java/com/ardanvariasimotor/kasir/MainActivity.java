package com.ardanvariasimotor.kasir;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.pdf.PrintedPdfDocument;
import android.print.PrintManager;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.view.ViewGroup;
import java.io.FileOutputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    SharedPreferences db;
    LinearLayout content;
    ArrayList<Product> products = new ArrayList<>();
    ArrayList<CartItem> cart = new ArrayList<>();
    NumberFormat rp = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
    int BG = 0xFF151719, CARD = 0xFF242629, INPUT = 0xFF090A0B, WHITE = 0xFFF5F5F5,
        MUTED = 0xFFB9BDC3, YELLOW = 0xFFFFC107, GREEN = 0xFF43D17A, BLUE = 0xFF38BDF8;

    static class Product {
        String id, name, category; int sell, cost, stock;
        Product(String id,String name,String category,int sell,int cost,int stock){this.id=id;this.name=name;this.category=category;this.sell=sell;this.cost=cost;this.stock=stock;}
    }
    static class CartItem { Product p; int qty; CartItem(Product p,int qty){this.p=p;this.qty=qty;} }

    @Override public void onCreate(Bundle b){super.onCreate(b); rp.setMaximumFractionDigits(0); db=getSharedPreferences("ardan_variasi_motor",MODE_PRIVATE); loadProducts(); showHome();}

    GradientDrawable shape(int color, float radius){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g;
    }
    GradientDrawable strokeShape(int color, int stroke, int strokeColor, float radius){
        GradientDrawable g=shape(color,radius); g.setStroke(stroke,strokeColor); return g;
    }
    TextView text(String s,float size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(WHITE);v.setPadding(18,12,18,12);return v;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(16);b.setTextColor(WHITE);b.setAllCaps(false);b.setMinHeight(56);b.setPadding(14,6,14,6);b.setStateListAnimator(null);return b;}
    EditText edit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(MUTED);e.setTextColor(WHITE);e.setTextSize(16);e.setSingleLine(true);e.setPadding(16,8,16,8);e.setBackground(strokeShape(INPUT,1,0xFF3A3D42,18));return e;}
    TextView title(String s){TextView t=text(s,21);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);t.setTextColor(WHITE);t.setPadding(20,15,20,15);return t;}
    void page(String title){
        LinearLayout all=new LinearLayout(this);all.setOrientation(LinearLayout.VERTICAL);all.setBackgroundColor(BG);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(4,0,10,0);bar.setBackgroundColor(0xFFE50914);
        TextView back=text("‹",40);back.setGravity(Gravity.CENTER);back.setPadding(4,0,4,0);back.setOnClickListener(v->showHome());bar.addView(back,new LinearLayout.LayoutParams(54,64));
        TextView tt=text(title,21);tt.setTypeface(Typeface.DEFAULT,Typeface.BOLD);bar.addView(tt,new LinearLayout.LayoutParams(0,64,1));
        all.addView(bar,new LinearLayout.LayoutParams(-1,64));
        ScrollView scroll=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(14,14,14,28);scroll.addView(content);all.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(all);
    }
    void add(View v){content.addView(v,new LinearLayout.LayoutParams(-1,-2));}
    void addSpace(int h){Space s=new Space(this);add(s);s.getLayoutParams().height=h;}
    TextView cardText(String s,float size){TextView v=text(s,size);v.setBackground(strokeShape(CARD,1,0xFF34373C,18));v.setPadding(18,16,18,16);return v;}
    Button bigButton(String s){Button b=button(s);b.setTextSize(17);b.setMinHeight(64);b.setBackground(shape(0xFFE50914,18));return b;}
    Button menuButton(String s,int color){Button b=button(s);b.setTextSize(16);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setMinHeight(112);b.setGravity(Gravity.CENTER);b.setBackground(shape(color,20));return b;}
    TextView section(String s){TextView t=text(s,15);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setTextColor(0xFFCFD2D7);t.setPadding(4,10,4,8);return t;}
    void backButton(){Button b=button("←  Kembali");b.setBackground(strokeShape(0xFF25272B,1,0xFF42464D,16));b.setOnClickListener(v->showHome());addSpace(8);add(b);}

    void showHome(){
        LinearLayout all=new LinearLayout(this);all.setOrientation(LinearLayout.VERTICAL);all.setBackgroundColor(BG);
        LinearLayout scrollBox=new LinearLayout(this);scrollBox.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll=new ScrollView(this);scroll.addView(scrollBox);all.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setPadding(20,18,20,18);hero.setBackground(shape(0xFF0D0E10,0));
        TextView brand=text("ARDAN",32);brand.setTypeface(Typeface.DEFAULT,Typeface.BOLD_ITALIC);brand.setTextColor(WHITE);hero.addView(brand);
        TextView brand2=text("VARIASI MOTOR",20);brand2.setTypeface(Typeface.DEFAULT,Typeface.BOLD);brand2.setTextColor(0xFFFF2530);hero.addView(brand2);
        TextView sub=text("KASIR OFFLINE  •  JOK / SEAT  •  SKOTLITE",13);sub.setTextColor(MUTED);sub.setPadding(4,5,4,5);hero.addView(sub);
        scrollBox.addView(hero,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout welcome=new LinearLayout(this);welcome.setOrientation(LinearLayout.VERTICAL);welcome.setPadding(18,16,18,16);welcome.setBackground(shape(0xFF25272B,16));
        TextView w=text("Selamat datang 👋",20);w.setTypeface(Typeface.DEFAULT,Typeface.BOLD);welcome.addView(w);TextView wt=text("Kelola penjualan, stok, opname admin, dan laporan dari satu aplikasi.",14);wt.setTextColor(0xFFD4D7DB);welcome.addView(wt);LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(-1,-2);wp.setMargins(14,12,14,10);scrollBox.addView(welcome,wp);
        TextView h=text("MENU UTAMA",14);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.setTextColor(0xFF9FA4AA);h.setPadding(18,8,18,8);scrollBox.addView(h);
        LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);grid.setPadding(14,0,14,0);
        LinearLayout r1=new LinearLayout(this);r1.setOrientation(LinearLayout.HORIZONTAL);Button kasir=menuButton("🛒\nKASIR\nTransaksi Penjualan",0xFFE50914);Button stok=menuButton("📦\nSTOK & PRODUK\nKelola Barang",0xFF292C31);r1.addView(kasir,new LinearLayout.LayoutParams(0,116,1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,116,1);sp.setMargins(8,0,0,0);r1.addView(stok,sp);grid.addView(r1);
        LinearLayout r2=new LinearLayout(this);r2.setOrientation(LinearLayout.HORIZONTAL);Button laporan=menuButton("📊\nLAPORAN\nRiwayat Transaksi",0xFF1677E8);Button opname=menuButton("📋\nOPNAME STOCK\nAdmin",0xFF16A34A);r2.addView(laporan,new LinearLayout.LayoutParams(0,116,1));LinearLayout.LayoutParams sp2=new LinearLayout.LayoutParams(0,116,1);sp2.setMargins(8,0,0,0);r2.addView(opname,sp2);grid.addView(r2);
        LinearLayout r3=new LinearLayout(this);r3.setOrientation(LinearLayout.HORIZONTAL);Button pin=menuButton("🔐\nGANTI PIN\nKeamanan Akun",0xFF6D28D9);Button keluar=menuButton("⏻\nKELUAR\nTutup Aplikasi",0xFFF57C00);r3.addView(pin,new LinearLayout.LayoutParams(0,116,1));LinearLayout.LayoutParams sp3=new LinearLayout.LayoutParams(0,116,1);sp3.setMargins(8,0,0,0);r3.addView(keluar,sp3);grid.addView(r3);
        scrollBox.addView(grid);kasir.setOnClickListener(v->showKasir());stok.setOnClickListener(v->showProducts());laporan.setOnClickListener(v->showReports());opname.setOnClickListener(v->admin(this::showOpname));pin.setOnClickListener(v->admin(this::changePin));keluar.setOnClickListener(v->finish());
        LinearLayout nav=new LinearLayout(this);nav.setPadding(8,6,8,6);nav.setGravity(Gravity.CENTER);nav.setBackgroundColor(0xFF101113);String[] ns={"⌂\nBeranda","🛒\nTransaksi","▣\nProduk","▥\nLaporan"};for(int i=0;i<4;i++){TextView n=text(ns[i],12);n.setGravity(Gravity.CENTER);n.setTextColor(i==0?0xFFFF2530:MUTED);nav.addView(n,new LinearLayout.LayoutParams(0,62,1));if(i==1)n.setOnClickListener(v->showKasir());if(i==2)n.setOnClickListener(v->showProducts());if(i==3)n.setOnClickListener(v->showReports());}all.addView(nav,new LinearLayout.LayoutParams(-1,70));setContentView(all);
    }

    void showProducts(){
        page("Stok & Produk");
        add(cardText("📦  Pantau stok, harga jual, modal, dan kategori produk.",16));addSpace(10);
        Button addProduct=bigButton("＋  TAMBAH PRODUK BARU");addProduct.setOnClickListener(v->addProduct());add(addProduct);addSpace(10);
        if(products.isEmpty()) add(cardText("Belum ada produk. Tambahkan produk pertama di bawah.",16));
        for(Product p:products){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(10,10,10,10);row.setBackground(strokeShape(0xFF242629,1,0xFF35383D,18));
            TextView icon=text("🏍️",28);icon.setGravity(Gravity.CENTER);row.addView(icon,new LinearLayout.LayoutParams(54,80));
            TextView info=text(p.name+"\n"+(p.category.isEmpty()?"Umum":p.category)+"  •  Stok: "+p.stock+"\n"+money(p.sell),16);info.setTypeface(Typeface.DEFAULT,Typeface.BOLD);row.addView(info,new LinearLayout.LayoutParams(0,88,1));
            Button plus=button("+");plus.setTextSize(22);plus.setBackground(shape(0xFFE50914,16));plus.setOnClickListener(v->{if(p.stock>0){updateCart(p,cartQty(p)+1);toast("Ditambahkan ke keranjang");}else toast("Stok habis");});row.addView(plus,new LinearLayout.LayoutParams(54,54));content.addView(row);addSpace(8);
        }
        Button op=button("🔐  OPNAME STOCK (ADMIN)");op.setBackground(strokeShape(0xFF25272B,1,0xFF42464D,16));op.setOnClickListener(v->admin(this::showOpname));add(op);backButton();
    }

    void addProduct(){
        page("TAMBAH PRODUK");add(cardText("Masukkan data barang. Gunakan harga jual dan modal agar laporan laba lebih akurat.",16));addSpace(8);
        EditText name=edit("Nama produk"),cat=edit("Kategori (contoh: Jok / Skotlite)"),sell=edit("Harga jual"),cost=edit("Harga modal"),stock=edit("Stok awal");
        sell.setInputType(InputType.TYPE_CLASS_NUMBER);cost.setInputType(InputType.TYPE_CLASS_NUMBER);stock.setInputType(InputType.TYPE_CLASS_NUMBER);
        add(name);addSpace(8);add(cat);addSpace(8);add(sell);addSpace(8);add(cost);addSpace(8);add(stock);addSpace(10);
        Button save=bigButton("💾  SIMPAN PRODUK");save.setOnClickListener(v->{if(name.getText().toString().trim().isEmpty()){toast("Nama produk wajib diisi");return;}products.add(new Product(UUID.randomUUID().toString(),name.getText().toString().trim(),cat.getText().toString().trim(),num(sell),num(cost),num(stock)));saveProducts();toast("Produk tersimpan");showProducts();});add(save);
        Button cancel=button("BATAL");cancel.setOnClickListener(v->showProducts());add(cancel);
    }

    void showKasir(){
        page("Kasir");
        LinearLayout search=new LinearLayout(this);search.setPadding(0,0,0,8);EditText q=edit("🔍  Cari produk...");search.addView(q,new LinearLayout.LayoutParams(0,52,1));add(search);
        add(section("PRODUK TERSEDIA"));
        if(products.isEmpty()) add(cardText("Belum ada produk. Masuk ke Stok & Produk untuk menambah barang.",16));
        for(Product p:products){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(10,8,8,8);row.setBackground(strokeShape(0xFF242629,1,0xFF35383D,16));
            TextView pic=text("🏍️",27);pic.setGravity(Gravity.CENTER);row.addView(pic,new LinearLayout.LayoutParams(52,72));
            TextView info=text(p.name+"\n"+money(p.sell)+"\nStok: "+p.stock,15);info.setTypeface(Typeface.DEFAULT,Typeface.BOLD);row.addView(info,new LinearLayout.LayoutParams(0,78,1));
            Button minus=button("−"),qty=button("0"),plus=button("+");minus.setTextSize(20);plus.setTextSize(20);minus.setBackground(shape(0xFF36393E,14));plus.setBackground(shape(0xFFE50914,14));qty.setTextColor(WHITE);qty.setBackgroundColor(0xFF151719);minus.setMinWidth(45);qty.setMinWidth(48);plus.setMinWidth(45);final int[] qq={cartQty(p)};qty.setText(String.valueOf(qq[0]));minus.setOnClickListener(v->{if(qq[0]>0)qq[0]--;qty.setText(String.valueOf(qq[0]));updateCart(p,qq[0]);});plus.setOnClickListener(v->{if(qq[0]>=p.stock){toast("Stok tidak cukup");return;}qq[0]++;qty.setText(String.valueOf(qq[0]));updateCart(p,qq[0]);});row.addView(minus);row.addView(qty);row.addView(plus);content.addView(row);addSpace(7);
        }
        int totalCart=0,totalQty=0;for(CartItem c:cart){totalCart+=c.p.sell*c.qty;totalQty+=c.qty;}
        LinearLayout sum=new LinearLayout(this);sum.setGravity(Gravity.CENTER_VERTICAL);sum.setPadding(16,12,16,12);sum.setBackground(shape(0xFF25272B,18));TextView si=text("Keranjang  •  "+totalQty+" item\nSubtotal",15);si.setTypeface(Typeface.DEFAULT,Typeface.BOLD);sum.addView(si,new LinearLayout.LayoutParams(0,62,1));TextView sv=text(money(totalCart),19);sv.setTypeface(Typeface.DEFAULT,Typeface.BOLD);sv.setGravity(Gravity.CENTER);sum.addView(sv);addSpace(8);add(sum);
        Button pay=bigButton("🛒  CHECKOUT  ›");pay.setOnClickListener(v->checkout());addSpace(8);add(pay);
    }

    int cartQty(Product p){for(CartItem c:cart)if(c.p.id.equals(p.id))return c.qty;return 0;}
    void updateCart(Product p,int q){CartItem found=null;for(CartItem c:cart)if(c.p.id.equals(p.id)){found=c;break;}if(q<=0){if(found!=null)cart.remove(found);}else if(found==null)cart.add(new CartItem(p,q));else found.qty=q;}

    void checkout(){
        if(cart.isEmpty()){toast("Keranjang kosong");return;}int sub=0,profit=0;for(CartItem c:cart){sub+=c.p.sell*c.qty;profit+=(c.p.sell-c.p.cost)*c.qty;}final int subtotal=sub,profitFinal=profit;
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(8,0,8,0);EditText disc=edit("Diskon Rp"),pay=edit("Bayar / DP Rp");disc.setInputType(InputType.TYPE_CLASS_NUMBER);pay.setInputType(InputType.TYPE_CLASS_NUMBER);box.addView(disc);addViewSpace(box,8);box.addView(pay);
        new AlertDialog.Builder(this).setTitle("💳 PEMBAYARAN").setMessage("Subtotal: "+money(subtotal)).setView(box).setPositiveButton("SIMPAN",(dialog,which)->{
            int total=Math.max(0,subtotal-num(disc));int paid=num(pay);if(paid<total){toast("Pembayaran kurang");return;}for(CartItem c:cart)c.p.stock-=c.qty;saveProducts();int change=paid-total;
            StringBuilder r=new StringBuilder();r.append("ARDAN VARIASI MOTOR\n");r.append("==============================\n");r.append(new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US).format(new Date())).append("\n");r.append("------------------------------\n");for(CartItem c:cart)r.append(c.p.name).append("\n  ").append(c.qty).append(" x ").append(money(c.p.sell)).append(" = ").append(money(c.p.sell*c.qty)).append("\n");r.append("------------------------------\n");r.append("Subtotal : ").append(money(subtotal)).append("\nDiskon   : ").append(money(num(disc))).append("\nTOTAL    : ").append(money(total)).append("\nBayar    : ").append(money(paid)).append("\nKembali  : ").append(money(change)).append("\n==============================\nTerima kasih.");
            String receipt=r.toString();String old=db.getString("sales","");String date=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());db.edit().putString("sales",old+date+"|"+total+"|"+profitFinal+"\n").apply();cart.clear();showReceiptDialog(receipt);}).setNegativeButton("BATAL",null).show();
    }

    void addViewSpace(LinearLayout box,int h){Space s=new Space(this);box.addView(s,new LinearLayout.LayoutParams(1,h));}
    void showReceiptDialog(final String receipt){
        TextView tv=cardText(receipt,16);tv.setTextIsSelectable(true);ScrollView sc=new ScrollView(this);sc.addView(tv);LinearLayout box=new LinearLayout(this);box.setPadding(12,0,12,0);box.addView(sc,new LinearLayout.LayoutParams(-1,520));
        new AlertDialog.Builder(this).setTitle("✅ TRANSAKSI BERHASIL").setView(box).setPositiveButton("🖨️ CETAK STRUK",(d,w)->printReceipt(receipt)).setNeutralButton("📤 WHATSAPP",(d,w)->share(receipt)).setNegativeButton("SELESAI",(d,w)->showHome()).show();
    }

    void printReceipt(final String receipt){
        PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);if(pm==null){toast("Fitur cetak tidak tersedia di perangkat ini");return;}pm.print("Struk ARDAN VARIASI MOTOR",new ReceiptPrintAdapter(receipt),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
    }
    class ReceiptPrintAdapter extends PrintDocumentAdapter{
        String receipt;ReceiptPrintAdapter(String r){receipt=r;}
        public void onLayout(PrintAttributes oldA,PrintAttributes newA,CancellationSignal cs,LayoutResultCallback cb,Bundle extras){if(cs.isCanceled()){cb.onLayoutCancelled();return;}PrintDocumentInfo info=new PrintDocumentInfo.Builder("Struk-ARDAN-VARIASI-MOTOR.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build();cb.onLayoutFinished(info,true);}
        public void onWrite(PageRange[] pages,ParcelFileDescriptor fd,CancellationSignal cs,WriteResultCallback cb){PrintedPdfDocument doc=new PrintedPdfDocument(MainActivity.this,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());android.graphics.pdf.PdfDocument.Page page=doc.startPage(1);Canvas c=page.getCanvas();Paint p=new Paint();p.setColor(0xFF000000);p.setTextSize(12);p.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.NORMAL));float x=36,y=45;for(String line:receipt.split("\\n")){if(y>800)break;c.drawText(line,x,y,p);y+=18;}doc.finishPage(page);try{FileOutputStream out=new FileOutputStream(fd.getFileDescriptor());doc.writeTo(out);out.flush();out.close();doc.close();fd.close();cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){doc.close();try{fd.close();}catch(Exception ignored){}cb.onWriteFailed(e.getMessage());}}
    }

    void showOpname(){page("OPNAME STOCK");add(cardText("🔐 MODE ADMIN\nHanya admin yang dapat mengubah jumlah stok.",17));addSpace(10);for(Product p:products){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setBackgroundColor(CARD);row.setPadding(8,8,8,8);TextView n=text(p.name+"\nStok saat ini: "+p.stock,16);row.addView(n,new LinearLayout.LayoutParams(0,80,1));EditText st=edit("Stok");st.setInputType(InputType.TYPE_CLASS_NUMBER);st.setText(String.valueOf(p.stock));row.addView(st,new LinearLayout.LayoutParams(120,70));Button save=button("Simpan");save.setOnClickListener(v->{p.stock=num(st);saveProducts();toast("Stok diperbarui");});row.addView(save);content.addView(row);addSpace(8);}backButton();}

    void showReports(){page("LAPORAN");String raw=db.getString("sales","");String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());String month=today.substring(0,7);int daySales=0,dayProfit=0,monthSales=0,monthProfit=0,count=0;for(String line:raw.split("\\n")){if(line.trim().isEmpty())continue;String[] a=line.split("\\|");if(a.length<3)continue;try{int total=Integer.parseInt(a[1]),profit=Integer.parseInt(a[2]);count++;if(a[0].startsWith(today)){daySales+=total;dayProfit+=profit;}if(a[0].startsWith(month)){monthSales+=total;monthProfit+=profit;}}catch(Exception ignored){}}add(cardText("📅 HARI INI\nPenjualan : "+money(daySales)+"\nLaba       : "+money(dayProfit)+"\n\n📆 BULAN INI\nPenjualan : "+money(monthSales)+"\nLaba       : "+money(monthProfit)+"\nTransaksi  : "+count,18));addSpace(10);final int fds=daySales,fdp=dayProfit,fms=monthSales,fmp=monthProfit;final String fm=month;Button share=bigButton("📤  BAGIKAN LAPORAN");share.setOnClickListener(v->share("ARDAN VARIASI MOTOR\nLaporan "+fm+"\nPenjualan bulan: "+money(fms)+"\nLaba bulan: "+money(fmp)+"\nPenjualan hari ini: "+money(fds)+"\nLaba hari ini: "+money(fdp)));add(share);backButton();}

    void admin(final Runnable action){EditText pin=edit("PIN Admin");pin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);new AlertDialog.Builder(this).setTitle("🔐 AKSES ADMIN").setView(pin).setPositiveButton("MASUK",(d,w)->{if(db.getString("pin","1234").equals(pin.getText().toString()))action.run();else toast("PIN salah");}).setNegativeButton("BATAL",null).show();}
    void changePin(){EditText old=edit("PIN lama"),newer=edit("PIN baru");old.setInputType(18);newer.setInputType(18);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.addView(old);addViewSpace(box,8);box.addView(newer);new AlertDialog.Builder(this).setTitle("Ganti PIN Admin").setView(box).setPositiveButton("SIMPAN",(d,w)->{if(!db.getString("pin","1234").equals(old.getText().toString())){toast("PIN lama salah");return;}String n=newer.getText().toString();if(n.length()<4){toast("PIN minimal 4 angka");return;}db.edit().putString("pin",n).apply();toast("PIN berhasil diganti");}).setNegativeButton("BATAL",null).show();}

    int num(EditText e){try{String s=e.getText().toString().replace(".","").replace(",","").trim();return s.isEmpty()?0:Integer.parseInt(s);}catch(Exception ex){return 0;}}
    String money(int n){return rp.format(n).replace("Rp","Rp ");}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    void share(String s){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,s);startActivity(Intent.createChooser(i,"Bagikan / WhatsApp"));}
    void loadProducts(){products.clear();String raw=db.getString("products","");if(raw.isEmpty())return;for(String line:raw.split("\\n")){String[] a=line.split("\\|",-1);if(a.length<6)continue;try{products.add(new Product(a[0],a[1],a[2],Integer.parseInt(a[3]),Integer.parseInt(a[4]),Integer.parseInt(a[5])));}catch(Exception ignored){}}}
    void saveProducts(){StringBuilder s=new StringBuilder();for(Product p:products)s.append(p.id).append('|').append(p.name.replace("|"," ")).append('|').append(p.category.replace("|"," ")).append('|').append(p.sell).append('|').append(p.cost).append('|').append(p.stock).append('\n');db.edit().putString("products",s.toString()).apply();}
}
