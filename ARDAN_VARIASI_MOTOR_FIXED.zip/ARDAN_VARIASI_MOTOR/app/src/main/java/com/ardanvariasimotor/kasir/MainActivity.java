package com.ardanvariasimotor.kasir;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    SharedPreferences db;
    LinearLayout content;
    ArrayList<Product> products = new ArrayList<>();
    ArrayList<CartItem> cart = new ArrayList<>();
    NumberFormat rp = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));

    static class Product {
        String id, name, category;
        int sell, cost, stock;
        Product(String id, String name, String category, int sell, int cost, int stock) {
            this.id=id; this.name=name; this.category=category;
            this.sell=sell; this.cost=cost; this.stock=stock;
        }
    }
    static class CartItem {
        Product p; int qty;
        CartItem(Product p, int qty) { this.p=p; this.qty=qty; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        rp.setMaximumFractionDigits(0);
        db=getSharedPreferences("ardan_variasi_motor", MODE_PRIVATE);
        loadProducts();
        showHome();
    }

    TextView text(String s, int size) {
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size);
        v.setPadding(18,14,18,14); return v;
    }
    Button button(String s) { Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    EditText edit(String hint) { EditText e=new EditText(this); e.setHint(hint); e.setPadding(14,8,14,8); return e; }

    void page(String title) {
        LinearLayout all=new LinearLayout(this); all.setOrientation(LinearLayout.VERTICAL);
        TextView head=text(title,22); head.setGravity(Gravity.CENTER);
        all.addView(head,new LinearLayout.LayoutParams(-1,-2));
        ScrollView scroll=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content); all.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(all);
    }
    void add(android.view.View v){ content.addView(v,new LinearLayout.LayoutParams(-1,-2)); }
    void backButton(){ Button b=button("← Kembali"); b.setOnClickListener(v->showHome()); add(b); }

    void showHome(){
        page("ARDAN VARIASI MOTOR");
        add(text("Kasir offline • Jok/Seat • Skotlite",16));
        Button a=button("🛒 KASIR"); a.setOnClickListener(v->showKasir()); add(a);
        Button b=button("📦 PRODUK & STOCK"); b.setOnClickListener(v->showProducts()); add(b);
        Button c=button("🔐 OPNAME STOCK (ADMIN)"); c.setOnClickListener(v->admin(this::showOpname)); add(c);
        Button d=button("📊 LAPORAN HARIAN / BULANAN"); d.setOnClickListener(v->showReports()); add(d);
        Button e=button("🔑 GANTI PIN ADMIN"); e.setOnClickListener(v->admin(this::changePin)); add(e);
    }

    void showProducts(){
        page("PRODUK & STOCK");
        Button addProduct=button("＋ Tambah Produk"); addProduct.setOnClickListener(v->addProduct()); add(addProduct);
        for(Product p:products) add(text(p.name+"\n"+p.category+"\nHarga: "+money(p.sell)+"   Modal: "+money(p.cost)+"\nStok: "+p.stock,16));
        backButton();
    }

    void addProduct(){
        page("TAMBAH PRODUK");
        EditText name=edit("Nama produk"), cat=edit("Kategori"), sell=edit("Harga jual"), cost=edit("Harga modal"), stock=edit("Stok awal");
        sell.setInputType(InputType.TYPE_CLASS_NUMBER); cost.setInputType(InputType.TYPE_CLASS_NUMBER); stock.setInputType(InputType.TYPE_CLASS_NUMBER);
        add(name); add(cat); add(sell); add(cost); add(stock);
        Button save=button("SIMPAN PRODUK"); save.setOnClickListener(v->{
            if(name.getText().toString().trim().isEmpty()){ toast("Nama produk wajib diisi"); return; }
            products.add(new Product(UUID.randomUUID().toString(),name.getText().toString().trim(),cat.getText().toString().trim(),num(sell),num(cost),num(stock)));
            saveProducts(); toast("Produk tersimpan"); showProducts();
        }); add(save);
        Button cancel=button("BATAL"); cancel.setOnClickListener(v->showProducts()); add(cancel);
    }

    void showKasir(){
        page("KASIR");
        add(text("Tekan + atau − untuk mengatur jumlah barang.",15));
        for(Product p:products){
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView info=text(p.name+"\n"+money(p.sell)+" • stok "+p.stock,14); row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            Button minus=button("−"), qty=button("0"), plus=button("+");
            final int[] q={0};
            minus.setOnClickListener(v->{ if(q[0]>0)q[0]--; qty.setText(String.valueOf(q[0])); updateCart(p,q[0]); });
            plus.setOnClickListener(v->{ if(q[0]>=p.stock){toast("Stok tidak cukup");return;} q[0]++; qty.setText(String.valueOf(q[0])); updateCart(p,q[0]); });
            row.addView(minus); row.addView(qty); row.addView(plus); content.addView(row);
        }
        Button pay=button("💳 BAYAR / CHECKOUT"); pay.setOnClickListener(v->checkout()); add(pay); backButton();
    }

    void updateCart(Product p,int q){
        CartItem found=null; for(CartItem c:cart) if(c.p.id.equals(p.id)){found=c;break;}
        if(q<=0){if(found!=null)cart.remove(found);} else if(found==null)cart.add(new CartItem(p,q)); else found.qty=q;
    }

    void checkout(){
        if(cart.isEmpty()){toast("Keranjang kosong");return;}
        int sub=0, profit=0;
        for(CartItem c:cart){sub+=c.p.sell*c.qty; profit+=(c.p.sell-c.p.cost)*c.qty;}
        final int subtotal=sub;
        final int profitFinal=profit;
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        EditText disc=edit("Diskon Rp"), pay=edit("Bayar / DP Rp"); disc.setInputType(InputType.TYPE_CLASS_NUMBER); pay.setInputType(InputType.TYPE_CLASS_NUMBER);
        box.addView(disc); box.addView(pay);
        new AlertDialog.Builder(this).setTitle("Pembayaran").setMessage("Subtotal: "+money(subtotal)).setView(box)
            .setPositiveButton("SIMPAN",(dialog,which)->{
                int total=Math.max(0,subtotal-num(disc)); int paid=num(pay);
                if(paid<total){toast("Pembayaran kurang");return;}
                for(CartItem c:cart)c.p.stock-=c.qty; saveProducts();
                int change=paid-total;
                String receipt="ARDAN VARIASI MOTOR\n-------------------------\nSubtotal: "+money(subtotal)+"\nDiskon: "+money(num(disc))+"\nTOTAL: "+money(total)+"\nBayar: "+money(paid)+"\nKembalian: "+money(change)+"\n-------------------------\nTerima kasih.";
                String old=db.getString("sales",""); String date=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());
                db.edit().putString("sales",old+date+"|"+total+"|"+profitFinal+"\n").apply();
                cart.clear(); share(receipt); showHome();
            }).setNegativeButton("BATAL",null).show();
    }

    void showOpname(){
        page("OPNAME STOCK"); add(text("Hanya admin yang dapat mengubah stok.",15));
        for(Product p:products){
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView n=text(p.name,14); row.addView(n,new LinearLayout.LayoutParams(0,-2,1));
            EditText st=edit("Stok"); st.setInputType(InputType.TYPE_CLASS_NUMBER); st.setText(String.valueOf(p.stock)); row.addView(st,new LinearLayout.LayoutParams(170,-2));
            Button save=button("Simpan"); save.setOnClickListener(v->{p.stock=num(st);saveProducts();toast("Stok diperbarui");}); row.addView(save); content.addView(row);
        }
        backButton();
    }

    void showReports(){
        page("LAPORAN"); String raw=db.getString("sales",""); String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()); String month=today.substring(0,7);
        int daySales=0,dayProfit=0,monthSales=0,monthProfit=0,count=0;
        for(String line:raw.split("\\n")){ if(line.trim().isEmpty())continue; String[] a=line.split("\\|"); if(a.length<3)continue; try{int total=Integer.parseInt(a[1]), profit=Integer.parseInt(a[2]); count++; if(a[0].startsWith(today)){daySales+=total;dayProfit+=profit;} if(a[0].startsWith(month)){monthSales+=total;monthProfit+=profit;}}catch(Exception ignored){} }
        add(text("HARI INI\nPenjualan: "+money(daySales)+"\nLaba: "+money(dayProfit)+"\n\nBULAN INI\nPenjualan: "+money(monthSales)+"\nLaba: "+money(monthProfit)+"\nTransaksi: "+count,18));
        Button share=button("📤 Bagikan laporan"); share.setOnClickListener(v->share("ARDAN VARIASI MOTOR\nLaporan "+month+"\nPenjualan bulan: "+money(monthSales)+"\nLaba bulan: "+money(monthProfit)+"\nPenjualan hari ini: "+money(daySales)+"\nLaba hari ini: "+money(dayProfit))); add(share); backButton();
    }

    void admin(final Runnable action){
        EditText pin=edit("PIN Admin"); pin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("Akses Admin").setView(pin).setPositiveButton("MASUK",(d,w)->{if(db.getString("pin","1234").equals(pin.getText().toString()))action.run();else toast("PIN salah");}).setNegativeButton("BATAL",null).show();
    }
    void changePin(){
        EditText old=edit("PIN lama"), newer=edit("PIN baru"); old.setInputType(18); newer.setInputType(18); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.addView(old);box.addView(newer);
        new AlertDialog.Builder(this).setTitle("Ganti PIN Admin").setView(box).setPositiveButton("SIMPAN",(d,w)->{if(!db.getString("pin","1234").equals(old.getText().toString())){toast("PIN lama salah");return;}String n=newer.getText().toString();if(n.length()<4){toast("PIN minimal 4 angka");return;}db.edit().putString("pin",n).apply();toast("PIN berhasil diganti");}).setNegativeButton("BATAL",null).show();
    }

    int num(EditText e){try{return Integer.parseInt(e.getText().toString().replace(".","").replace(",","").trim().isEmpty()?"0":e.getText().toString().replace(".","").replace(",","").trim());}catch(Exception ex){return 0;}}
    String money(int n){return rp.format(n).replace("Rp","Rp ");}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    void share(String s){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,s);startActivity(Intent.createChooser(i,"Bagikan / WhatsApp"));}

    void loadProducts(){
        products.clear(); String raw=db.getString("products",""); if(raw.isEmpty())return;
        for(String line:raw.split("\\n")){String[] a=line.split("\\|",-1);if(a.length<6)continue;try{products.add(new Product(a[0],a[1],a[2],Integer.parseInt(a[3]),Integer.parseInt(a[4]),Integer.parseInt(a[5])));}catch(Exception ignored){}}
    }
    void saveProducts(){StringBuilder s=new StringBuilder();for(Product p:products)s.append(p.id).append('|').append(p.name.replace("|"," ")).append('|').append(p.category.replace("|"," ")).append('|').append(p.sell).append('|').append(p.cost).append('|').append(p.stock).append('\n');db.edit().putString("products",s.toString()).apply();}
}
