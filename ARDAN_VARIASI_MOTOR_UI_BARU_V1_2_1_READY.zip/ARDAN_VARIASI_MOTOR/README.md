# ARDAN VARIASI MOTOR — UI BARU V1.2.1

Kasir offline Android. PIN awal: 1234.

## Yang berubah
- Dashboard baru model kartu 2 kolom.
- Warna merah/putih/hitam dan tombol lebih besar.
- Bottom navigation untuk Beranda, Transaksi, Produk, dan Laporan.
- Header menampilkan badge **UI BARU • V1.2** agar mudah memastikan APK yang terpasang adalah build terbaru.
- Semua menu/fungsi lama dipertahankan, termasuk Kasir, Stok & Produk, Laporan, Opname Stock Admin, Ganti PIN, Checkout, Cetak Struk, dan Bagikan/WhatsApp.

## Build APK
Workflow GitHub Actions tersedia di `.github/workflows/build-apk.yml`.
Jalankan workflow **Build ARDAN VARIASI MOTOR APK**, lalu ambil artifact **ARDAN-VARIASI-MOTOR-APK**.

APK hasil build versi baru memiliki versionCode 4 dan versionName 1.2.1.
